package de.aurelie.banking.system.datei.zugriff;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * Hiermit will ich ein Textdatei (liste aller Konten) im verzeichninis  lesen.
 * Also ich m�chte die Liste aller Konten im Path (Datei) lesen 
 * 
 * @author Aurelie Koumtossa
 *
 */

public class KontoLeser {	
	/**
	 * lesen alle hinzugef�gt Konten als Text in Datei
	 * @param quelle datei die gelesen wird
	 * @return aller Konten aus Datei, oder null enn es beim Lesen der Datei Probleme gab
	 */
	public String lesenAlleKontenAlsTextAusdatei(File quelle) {
		String rueckgabeText = "";
		try( BufferedReader leser = new BufferedReader(new FileReader(quelle)) ){
			
			String gelesen = leser.readLine();
			rueckgabeText = gelesen + "\n";
			
			while(true){
				if(gelesen == null) {
					break;
				}
				rueckgabeText = rueckgabeText + gelesen + "\n";
				gelesen = leser.readLine();
			}
			
		} catch(IOException ausnahe) {
			ausnahe.printStackTrace();
		}
		
		return rueckgabeText;
	}

}
