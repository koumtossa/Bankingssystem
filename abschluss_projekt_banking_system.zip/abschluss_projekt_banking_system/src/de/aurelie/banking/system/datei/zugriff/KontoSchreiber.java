package de.aurelie.banking.system.datei.zugriff;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

/**
 * Hiermit will ich ein Textdatei (liste aller Konten) im verzeichninis  speichern bzw. schreiben.
 *
 * @author Aurelie Koumtossa
 */
public class KontoSchreiber {

	/**
	 * Schreiben alle Konten, die angelegt werden in einer Textdatei
	 * 
	 * @param ziel verzeichnis, wo die Textdatei angelegt wird
	 * @param text inhlat der Datei
	 */
	public void schreibenVonKontoInformationenInDatei(File ziel, String text) {
		try (Writer dateiSchreiber = new FileWriter(ziel, true);
				BufferedWriter besserSchreiber = new BufferedWriter(dateiSchreiber)) {
			besserSchreiber.write(text);
		} catch (IOException ausnahme) {
			ausnahme.printStackTrace();
		}
	}

}
