package de.aurelie.banking.system;

import java.util.Scanner;

/**
 * Klasse Manager:
 * 	ist ein Mitarbeiter einer Bank
 * und hat: - ein pk
 *			- name
 *			- passwort
 *
 * 	muss sich einloggen und erst dann kann (Frontend zu implementieren) :
 * 		- er neuesKontoanlegen (eroeffnenNeuesKonto()
 * 		-  loeschenKonto
 * 		- suchenKonto()
 * 		- anzeigenKontoListe()
 * 		-...
 * 
 * !!! KEIN Setters von Name.
 * 
 * @author Aurelie Koumtossa
 *
 */

public class Manager implements Login{
	
	/**************************************Die Attribute****************************************/
	
	/** eindeutige Nummer des Managers. 
	 * Aber in unsere BAnk gibt es nur ein Manager und  kann sein pk nicht ge�ndert werden. (final)
	 */
	private final int pk;
	
	/** enth�lt Name des Managers*/
	private String name;
	
	/** enth�lt das Passwort eines Managers */
	private String passwort;

	
	/********************************************Konstruktoren*********************************************/
	
	/**
	 * @param pk
	 * @param name
	 * @param passwort
	 */
	public Manager() {
		this.pk = 245; // ich nutze den Bezeichners unser Kursees
		this.name = "AurelieVans";
		this.passwort = "Kurs245";
	}

	
	/********************************Die Getters*************************************/

	/**
	 * liefern die Prim�rschl�sseln eines neues Objekts Managers
	 * @return the pk
	 */
	public int getPk() {
		return pk;
	}

	/**
	 * Liefert der Name eines neues Objekts Managers
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * lifert das Passwort eines neues Objekts Managers
	 * @return the passwort
	 */
	public String getPasswort() {
		return passwort;
	}

	/*****************************Die Setters**********************************************/
	
	/**
	 * Festlegen eines Passworts
	 * @param passwort the passwort to set
	 */
	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}

	/***************************************Die Methoden****************************************/
	
	/**
	 * �berschreiben von MEthode einloggen , damit ein Manager sich einloggen kann
	 * einloggen erfolgt erst nach der Pr�fung von pk und passwort durchgef�hrt werden
	 * @return true wenn pk und passwort korrekt sind
	 * @throws Exception abgefangen, wenn pk oder passwort oder beides nicht korrekt sind
	 */
	@Override
	public boolean einloggen(int pk, String passwort) throws Exception {
		
		System.out.println("Bitte Loggen Sie sich ein!\n ");
		/** Managernummer eingeben und einlesen */
		Scanner lesenManagerNummer = new Scanner(System.in);
		System.out.println("Geben Sie bitte die Managernummer (pk) ein!");
		 pk = lesenManagerNummer.nextInt();
		
		/** Managerpasswort eingeben und einlesen */
		Scanner lesenPasswort = new Scanner(System.in);
		System.out.println("Geben Sie bitte das Passwort ein!");
		 passwort = lesenPasswort.nextLine();
		
		
		if (pk == this.pk && passwort.equals(this.passwort)) {
	        System.out.println(  "Der Manager " + name + " hat sich erfolgsreich eingeloggt!");
	        return true;
	    }
//
	    else if (pk == this.pk) {
	    	throw new Exception("Falsches Passwort Eingabe!");
	    } else if (passwort.equals(this.passwort)) {
	    	throw new Exception("Falsche Managernummer!");
	    } else {
	        throw new Exception("Passwort und Managernummer sind falsch eingegeben.");
	    }
		
	}
	
	@Override
	public String toString() {
		return "ManagerNummer ist: " + pk + ", sein Name ist: " + name + ", und sein Passwort ist: " + passwort;
	}

}
