package de.aurelie.banking.system;

/**
 * Projekt: Banking system
 * Klassen Backend:
 *	- Kunde (name, adresse, konto) implements Login
 * 	- Konto (nummer, kontostand, kontotyp)
 * 		- SParkonto extends Konto 
 * 				--> �berschreibung f�r die Methoden Auszahlen (throws Exception)und Einzahlen 
 * 	- Enums: Kontotyp (GIROKONTO oder SPARKONTO)
 * 
 * 	- Interface-Login
 * 	- Manager implements Interface Login
 * 
 * 
 * Klassen-Middletier:
 * 	- KontoServices (zufuegen neues Konto, suchen ein Konto, auswaehlen ein Konto, ...)
 * 	- KundeServices (zufuegen neuer Kunde, suchen ein Kunde, auswaehlen ein Kunde, ...)
 * 
 * 
 * Klasse-Frontend:
 * 	- Benutzerinteraktion 
 * 		- einloggen ( Manager oder ein Kunde), wenn erfolgsreich
 * 		- anzeigen Menue und h�ngt von dem Eingeloggte (Manager oder Kunde)
 * 		- Menue von Manager ist beschr�nkt zu:
 * 			- anlegen neues Konto --> direkt wird auch ein Kunde angelegt
 * 			- anzeigen Liste aller Konten oder Kunden
 * 			- suchen ein Konto oder ein Kunde
 * 			- loeschen ein Konto --> direkt auch der Kunde wird gel�scht
 * 			- ausloggen ( zeigt der Kunden-Menupunkt --> f�r die weitere Nutzung von erzeugten Daten )
 * 		- Menue von Kunden ist auch beschr�nkt zu:
 * 			- einzahlen Geld im Konto
 * 			- auszahlen Geld Vom Konto
 * 			- �berweisen Geld vonKonto (auszahlen hier) NachKonto (einzahlen hier erfolgt)
 * 			- anzeigen alle seiner Konten (Ein Kunde kann mehrere Konten haben)
 * 			- anzeigen seine KontenInformationen oder seine pers�nliche Stammdaten
 * 
 * 
 * Datei-zugriff-Klassen
 * 		-KontoSchreiber 
 * 				--> die Liste aller angelegten Konten werden in einer Textdatei geschreiben
 * 		-KontoLeser 
 * 				--> die Textdatei (Kontenliste) wird beim Beenden des Programs gelesen 
 * 					und in die Konsole ausgegeben  aber danach gel�scht
 * 	
 * zu erg�nzen:
 * 		- Exceptin f�r nicht Eingeloggter 
 * 		- Datenbank
 * 		- GUI
 * 
 * 
 * @author Alfa
 *
 */

public class Vortrag {

}
