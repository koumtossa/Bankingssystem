package de.aurelie.banking.system;

/**
 * Login Interface
 * Die Benutzer eines Bankings muss sich bevor Zugriff an vrschiedene Transaktionen 
 * wie neuesKontohinzuf�gen, konto suchen, l�schen , einzahlen, auszahlen oder �berweisen , ... einloggen
 * 
 * Diese Interface w�re ein funktionales Interface mit der abstrakte Methode einloggen(), 
 * die hier nicht implementiert werden wird, sondern in untereklasse Kunden und Manager implementiert werden.
 * 
 * @author Aurelie Koumtossa
 *
 */
@FunctionalInterface
public interface Login {
	
	/** diese abstrakte Methode nimmt zwei Parametern username und passwort
	 * ein Benutzer muss eingeloggt werden
	 * 
	 * @param loginId, loginId eines Benutzer (KundenId f�r ein Kunde oder  pk f�r Manager)
	 * @param loginPasswort (Passwort eines Manager und Pin f�r ein Kunde)
	 * @throws Exception 
	 */
	public boolean einloggen(int loginId, String loginPasswort) throws Exception;

}
