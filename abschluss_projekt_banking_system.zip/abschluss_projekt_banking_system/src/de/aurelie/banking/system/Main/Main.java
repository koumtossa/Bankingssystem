package de.aurelie.banking.system.Main;

import de.aurelie.banking.system.services.KontoServices;
import de.aurelie.banking.system.userinteraktion.BankingBenutzerInteraktion;

/**
 * Main des Systemy wird implementiert
 * @author Aurelie Koumtossa
 *
 */
public class Main {

	/**
	 * Main unseres Bankingssystem 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		KontoServices bankingServices = new KontoServices();
		BankingBenutzerInteraktion interaktion = new BankingBenutzerInteraktion(bankingServices);
		interaktion.launch();
	}
}
