package de.aurelie.banking.system;

import java.io.Serializable;

/**
 * F�r einen Kunde wird ein Konto erstellt.
 * 
 * Klasse Konto: ein Konto geh�hrt zu einem Kunde, hat - eine Kontonummer - hat
 * ein Kontostand - hat ein Kontotyp ( als Enums (Kontotyp) initialisiert mit
 * den Werten GiroKonto und Sparkonto) Ein Girokonto ist noch ein normales Konto
 * und daher das default. wird gar nicht implemetiert.
 * 
 * ein Konto kann (mehoden) - er�ffnen werden, hinzuf�genNeuesKonto() - in einem
 * Konto kann Gelb eingezahlt oder abgehoben werden - kann informationen zu den
 * Konto angezeigt werden
 * 
 * @author Aurelie Koumtossa
 *
 */

public class Konto implements Serializable {

	/*****************************************
	 * Die Attribute
	 ***************************************************************/

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** Nummer einer Konto, die bei der Erstellung eines Konto vergeben wird */
	protected int kontoNummer;

	/**
	 * Helfer f�r die Erstelleung einer Kontonummer und alle kontonummer f�ngt bei
	 * der Erstellung ab 1
	 */
	protected static int KONTONUMMERGENERATOR = 1;

	/**
	 * ist der Kontostand eines Konto, also wie viel geld ein Kunde in seinem Konto
	 * noch zur Verf�gung hat
	 */
	protected double kontostand;

	/**
	 * ist der Besitzer eines Konto, also ein Attribut-Objekt von der Klasse Kunde
	 * und die Daten werden von der Klasse Kunden gelesen
	 */
	protected Kunde kunde;

	/** GIROKONTO, SPARKONTO als Enums */
	protected Kontotyp kontoArt;

	/** Referenzielle Attribute f�r die �berweisung */
	protected Konto vonKonto; // Sender
	protected Konto nachKonto; // Empfaenger

	/*****************************************
	 * Konstruktoren
	 ******************************************/

	/**
	 * pro Kunde wird eine Kontonummer vergeben und diese wird immer durch
	 * inkremetierung der Kontonummergenerator. Ein neues Konto hat am Anfang eine 0
	 * -Wert als Start Kontostand/Guthaben default kontotyp = GIROKONTO
	 */
	public Konto() {
		this.kontoNummer = KONTONUMMERGENERATOR++;
		this.kontostand = 0;
		this.kontoArt = Kontotyp.GIROKONTO;
	}

	/**
	 * pro Kunde wird eine Kontonummer vergeben und diese wird immer durch
	 * inkremetierung der Kontonummergenerator. Ein neues Konto hat am Anfang eine 0
	 * -Wert als Start Kontostand/Guthaben
	 * 
	 * @param kontoNummer
	 * @param kontostand
	 */
	public Konto(int kontoNummer, Kontotyp kontoart) {
		this.kontoNummer = KONTONUMMERGENERATOR++;
		this.kontoArt = kontoart;
	}

	/**
	 * pro Kunde wird eine Kontonummer vergeben und diese wird immer durch
	 * inkremetierung der Kontonummergenerator. Ein neues Konto hat am Anfang eine 0
	 * -Wert als Start Kontostand/Guthaben
	 * 
	 * @param kontoNummer
	 * @param kontostand
	 */
	public Konto(double kontostand, Kontotyp kontoart) {
		this.kontoNummer = KONTONUMMERGENERATOR++;
		this.kontostand = kontostand;
		this.kontoArt = kontoart;
	}

	/****************************************************
	 * Die Getters
	 **************************************/

	/**
	 * Liefert die Nummer eines Konto zur�ck
	 * 
	 * @return the kontoNummer
	 */
	public int getKontoNummer() {
		return kontoNummer;
	}

	/**
	 * @return the kONTONUMMERGENERATOR
	 */
	public static int getKONTONUMMERGENERATOR() {
		return KONTONUMMERGENERATOR;
	}

	/**
	 * Liefert der Stand bzw. Saldo eines Konto zur�ck
	 * 
	 * @return the kontostand
	 */
	public double getKontostand() {
		return kontostand;
	}

	/**
	 * @return the kunde
	 */
	public Kunde getKunde() {
		return kunde;
	}

	/**
	 * @return the kontoArt
	 */
	public Kontotyp getKontoArt() {
		return kontoArt;
	}

	/**************************************************
	 * Die Setters
	 **********************************************/

	/**
	 * Festlegen von kontonummer
	 * 
	 * @param kontoNummer the kontoNummer to set
	 */
	public void setKontoNummer(int kontoNummer) {
		this.kontoNummer = kontoNummer;
	}

	/**
	 * @param kONTONUMMERGENERATOR the kONTONUMMERGENERATOR to set
	 */
	public static void setKONTONUMMERGENERATOR(int kONTONUMMERGENERATOR) {
		Konto.KONTONUMMERGENERATOR = kONTONUMMERGENERATOR;
	}

	/**
	 * Festlegen von Kontostand
	 * 
	 * @param kontostand the kontostand to set
	 */
	public void setKontostand(double kontostand) {
		this.kontostand = kontostand;
	}

	/**
	 * Festlegen von kunde
	 * 
	 * @param kunde the kunde to set
	 */
	public void setKunde(Kunde kunde) {
		this.kunde = kunde;
	}

	/******************************************************
	 * Die Methoden
	 ********************************************/

	/**
	 * bei der Auszahlung wird der Betrag von dem aktuellen Kontostand substrahiert
	 * werden. Allerdings wird eine �berpr�fung durchgef�hrt: Mann kann nur abheben,
	 * wenn der Kontostand es erlaub( Deckungsreichung) if-Verzweigung sp�ter durch
	 * 
	 * @param betrag, der man in einem Konto abheben bzw. auszahlen will
	 * @throws Exception
	 */
	public boolean auszahlenGeldVomKonto(double betrag) throws Exception {

		if (betrag < 0) {
			throw new Exception("Bitte geben Sie einen positiver Wert ein!");
		}
		if (betrag > kontostand) {
			System.out.println("Ihr Kontostand betr�gt: " + kontostand + "�");
			throw new Exception("Sie haben nicht genug Geld auf Ihrem Konto, um diese Transaktion zu machen.");
		}

		kontostand = kontostand - betrag;
		return true;
	}

	/**
	 * bestimmter Betrag/Geld in einem Konto einzahlen bei der Einzahleung erh�ht
	 * sich unserer Kontostand, weil der eingezahlte Betrag in dem aktuellen
	 * Kontostand addiert wird
	 * 
	 * @param betrag, der ein Kunde in seinem Konto einzahlen will
	 */
	public boolean einzahlenGeldInKonto(double betrag) {
		if (betrag <= 0) {
			System.err
					.println("Bitte geben Sie einen positiver Wert ein und dieser muss auch gr��er als 0 sein. Danke!");
			return false;
		}

		kontostand = kontostand + betrag;
		return true;
	}

	/**
	 * Bei einer �berweisung braucht man zwei Konten vonKonto, der als Sender
	 * betrachtret wird und nachKono der als Empfaenger ist. dr sender f�hrt somit
	 * eine Auszahlung in seinem Konto und dder Empfanger erh�lt bei dieser
	 * Transaktion mehr geld, Als Geld Einzahlung
	 * 
	 * @param vonKonto
	 * @param nachKonto
	 * @param betrag
	 * @return
	 * @throws Exception
	 */
	public boolean ueberweisenGeldVonKontoNachKonto(Konto vonKonto, Konto nachKonto, double betrag) throws Exception {
		vonKonto.auszahlenGeldVomKonto(betrag);
		nachKonto.einzahlenGeldInKonto(betrag);
		return true;
	}

	/**
	 * anzeigen von Informationen eines Kontos eines entsprechende Kunde
	 * 
	 * @throws Exception
	 */
	public void anzeigenKontoDetails() {
		System.out.println(kontoNummer + "\t\t" + kunde.getName() + "\t" + kunde.getAdresse() + "\t" + kontostand + "�"
				+ "\t\t" + kontoArt);
	}

	/**
	 * �berschreiben von object-Method toStrin()
	 */
	@Override
	public String toString() {
		return "kontoNummer: " + kontoNummer + ", kontostand: " + kontostand;
	}

}
