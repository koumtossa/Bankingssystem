package de.aurelie.banking.system;

import java.io.Serializable;

/**
 * Alle Kunden haben (Attribute:) - einen Namen (String) - eine Adresse (String)
 * - ein Konto (Konto) - kundenId(int) - kundenPasswort(String)
 * 
 * Kunden k�nnen (Methoden) in einem Bank: - anzeigenKontoStandsUebersicht() -
 * anzeigenKundenInformationen()
 * 
 * @author Aurelie Koumtossa
 */

public class Kunde implements Serializable, Login {

	/********************************************
	 * Die Attribute
	 ***********************************/

	/** default serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** Name des Kunden */
	private String name;

	/** Adresse des Kunden */
	private String adresse;

	/** Referenz Attribut von der Klasse Konto */
	private Konto konto;

	/** enth�lt der Kundenid f�r das Einloggen */
	private int kundenId;

	private static int KUNDENUMMERGENERATOR = 1;

	/** enth�lt das Kundenpasswort f�r das Einloggen */
	private String kundenPasswort;

	/**********************************************
	 * Die Konstruktoren
	 ****************************/

	/**
	 * Konstruktor Kunde mit den Parametern erzeugt einen neuen Kunden mit dem
	 * entsprechenden Namen und Adresse Hilft mir beim Testen des programms
	 * 
	 * @param name
	 * @param adresse
	 */
	public Kunde(String name, String adresse, String kundenPasswort) {
		this.name = name;
		this.adresse = adresse;
		this.kundenId = KUNDENUMMERGENERATOR++;
		this.kundenPasswort = kundenPasswort;
	}

	/**
	 * erzeugt eines neue Kunde mit name und adresse
	 * 
	 * @param name
	 * @param adresse
	 */
	public Kunde(String name, String adresse) {
		this.name = name;
		this.adresse = adresse;
	}

	/********************************
	 * * Die Getters
	 ********************************************/

	/**
	 * @return the name eines Objekts Kunde
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the adresse eines Objekts Kunde
	 */
	public String getAdresse() {
		return adresse;
	}

	/**
	 * @return the konto eines Objekts Kunde
	 */
	public Konto getKonto() {
		return konto;
	}

	/**
	 * @return the kundenId
	 */
	public int getKundenId() {
		return kundenId;
	}

	/**
	 * @return the kundenPasswort
	 */
	public String getKundenPasswort() {
		return kundenPasswort;
	}

	/******************************************************
	 * Die Setters
	 **************************/

	/**
	 * Festlegen von Name eines Kunde
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Festlegen von Adresse eines Kunde
	 * 
	 * @param adresse the adresse to set
	 */
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	/**
	 * @param konto the konto to set
	 */
	public void setKonto(Konto konto) {
		this.konto = konto;
	}

	/**
	 * @param kundenId the kundenId to set
	 */
	public void setKundenId(int kundenId) {
		this.kundenId = kundenId;
	}

	/**
	 * @param kundenPasswort the kundenPasswort to set
	 */
	public void setKundenPasswort(String kundenPasswort) {
		this.kundenPasswort = kundenPasswort;
	}

	/*************************************************
	 * Die Methoden
	 **********************************************/

	/**
	 * liefert alle Informationen im bezug eines Kunde in Form einer Tabelle zur�ck
	 */
	public void anzeigenKundenInformationen() {
		System.out.println(name + "\t" + adresse + "\t\t" + kundenId + "\t\t" + kundenPasswort + "\t\t"
				+ konto.getKontoNummer() + "\t\t" + konto.getKontostand());
	}

	/**
	 * einloggen eines Kunde im System
	 * 
	 */
	@Override
	public boolean einloggen(int kundenId, String passwort) throws Exception {
		if (kundenId == this.kundenId && passwort.equals(this.kundenPasswort)) {
			System.out.println("Der Kunde: " + name + " hat sich erfolgsreich eingeloggt!");
			return true;
		}
//
		else if (kundenId == this.kundenId) {
			throw new Exception("Falsches Passwort Eingabe!");
		} else if (passwort.equals(this.kundenPasswort)) {
			throw new Exception("Falscher KundeId!");
		} else {
			throw new Exception("Passwort und KundeId sind falsch eingegeben.");
		}
	}

	/**
	 * �berschreiben von object-Method toStrin()
	 */
	@Override
	public String toString() {
		return "Kunde [name=" + name + ", adresse=" + adresse;
	}

}
