package de.aurelie.banking.system;

/**
 * Klasse Bank: 
 * somit hat unsere Bank schon ein vor initialisierter Name( wird als final deklariert)
 * Grund: ich will nicht, dass der Name festlegen werden kann -> KEIN Setter
 * Der Name wird im Konstruktor vergeben
 * 
 * @author Aurelie Koumtossa
 *
 */

public class Bank {

	/**********************************Attribute********************************************/
	
	/** Name der Bank  und durch das Schl�sselwort "final" kann nicht mehr ver�ndert werden*/
	protected final String name;

	/*******************************************Der Konstruktor******************************/
	/**
	 * Konstruktor ohne Paramtern
	 * und legt den Name des Objekts Bank fest
	 *  erzeugt eine neue Bank mit gegebenen Namen
	 */ 
	public Bank() {
		this.name = "Aurelie-Bank Fuer Kurs 245";
	}
	
	/************************************* Die Getters **********************************/
	/**
	 * liefert der Name einer Bank
	 * @return the name
	 */
	public String getName() {
		return name;
	}
}

