package de.aurelie.banking.system.userinteraktion;

import java.io.File;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

import de.aurelie.banking.system.Bank;
import de.aurelie.banking.system.Konto;
import de.aurelie.banking.system.Kontotyp;
import de.aurelie.banking.system.Kunde;
import de.aurelie.banking.system.Manager;
import de.aurelie.banking.system.Sparkonto;
import de.aurelie.banking.system.datei.zugriff.KontoLeser;
import de.aurelie.banking.system.datei.zugriff.KontoSchreiber;
import de.aurelie.banking.system.services.KontoServices;
import de.aurelie.banking.system.services.KundenServices;

/**
 * Dient hier als Frontend unseres System ein einfaches Bankingsystem gemessen
 * an der Realit�t programmieren.
 * 
 * Unser BenutzerInteraktion sollte : - der Name unserer Bank in das
 * Begr��ungswort in die Konsole ausgeben k�nnen - die Liste aller Konten
 * auflisen k�nnen - die Kontoarten unterscheiden k�nnen und in diese in
 * Kontoliste auslesen k�nnen - Ein- und Auszahlungen sowie �berweisungen
 * durchgef�hrt werden k�nnen - Der Kontotyp Sparkonto ein Limit bzw,
 * Mindestsaldo aufweisen k�nnen. (Throws aufwerfen bei Auszahlung, damit
 * Mindestsaldobestand von 100 euro nicht mehr steht) - Ein Kunde in unserem
 * System hinzuf�gen k�nnen - Ein Konto in unserem System suchen, l�schen,
 * hinzuf�gen, k�nnen - Die Liste alle Konten in einem Datei speichern und in
 * die Konsole auslesen k�nnen - Die Liste aller Konten (Datei) beim Beenden des
 * Programms immer l�schen k�nnen. (Also diese Liste steht hier nur als
 * tempor�re Speicher)
 * 
 * @author Aurelie Koutmossa
 */
public class BankingBenutzerInteraktion {

	/** damit wird die Name der bank �bernommen */
	private Bank dieBank;

	/** Referenz Attribut f�r ein Manager */
	private Manager derManager;

	/** Stellt die Services zur Verf�gung, die hier benutzt werden */
	private KontoServices kurs245Services = new KontoServices();
	private KundenServices kundenService = new KundenServices();

	/** Liste alle Konten, die der Kontoservices-Klasse zur Verf�gung stellt */
	List<Konto> konten = kurs245Services.getAlleKonten();

	/**
	 * Das Frontend bekommt den Service von "au�en"
	 * 
	 * @param kurs245 festlegen des kontotoservices
	 */
	public BankingBenutzerInteraktion(KontoServices kurs245) {
		this.kurs245Services = kurs245;
	}

	/**
	 * Starten die Navigation durch das Frontend
	 * 
	 * @throws Exception
	 */
	public void launch() throws Exception {
		/** Erstellen eines neues Objekt Bank */
		dieBank = new Bank();
		System.out.println("\n******************Herzlich Willkommen bei der " + dieBank.getName()
				+ " Abschluss Projekt****************************\n");

		// anzeigen von navigierenMenue von Manager, wen dieser eingeloggt ist und wenn
		// die Liste aller Konten leer ist
		/**
		 * der Manager LoginID = 245 und Passwort = Kurs245 und wurden im Konstruktor
		 * von der Klasse Manager festgelegt
		 */
		derManager = new Manager();
		int pk = derManager.getPk();
		boolean einloggen = true;
		String passwort = derManager.getPasswort();
		derManager.einloggen(pk, passwort);
		System.out.println("\nWillkommen in Manager-Navigationmenu \n");
		navigierenManagerMenue();

		// anzeigen von vanigierenKundenMenue, wenn dieser eingeloggt ist

	}

	/**
	 * Starten die Navigation von ManagerInterface
	 */
	private void navigierenManagerMenue() {
		System.out.println("Bitte w�hlen Sie eine Menu-option aus!:\n\t" + "1: neues Konto anlegen\n\t"
				+ "2: Anzeigen aller Konten\n\t" + "3: Konto suchen\n\t" + "4: Konto l�schen\n\t"
				+ "5: anzeigen alle Kunden\n\t" + "6: ausloggen\n\t"
				+ "oder Programm beenden mit jeder anderen Zahleingabe");

		int auswahl = new Scanner(System.in).nextInt();
		switch (auswahl) {
		case 1:
			anlegenNeuesKonto();
			break;
		case 2:
			anzeigenAlleKonten();
			break;
		case 3:
			suchenEinKonto();
			break;
		case 4:
			loeschenEinKonto();
			break;
		case 5:
			anzeigenAllerKunden();
			break;
		case 6:
			try {
				System.out.println("Manager " + derManager.getName() + " ist ausgeloggt.");
				navigierenKundeMenue();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		default:
			System.out.println("\nProgramm wird beendet.");

			if (new File("objektKonto/alleKonten.txt").exists()) {
				/**
				 * Beim Beenden des Programms wird die Liste alle Konten, di beim Er�ffnn
				 * geschreiben in "objektKonto/konto.kontenListe", gelesen und in der Konsole
				 * ausgegeben.
				 */
				System.out.println("\n***************Anfang Auslesen von Konteliste aus Datei   " + LocalTime.now()
						+ "  **********************");
				KontoLeser leserAusDatei = new KontoLeser();
				String alleKontenAusDatei = leserAusDatei
						.lesenAlleKontenAlsTextAusdatei(new File("objektKonto/alleKonten.txt"));
				System.out.println(alleKontenAusDatei);
				System.out.println(
						"**************Auslesen ist beendet   " + LocalTime.now() + "  **********************\n");

				/**
				 * Nach dem Lesen wird die geschriebe Datei "objektKonto/konto.kontenListe"
				 * gel�scht, damit beim Neustarten des Programms eine neue Datei immer erstellt
				 * wird.
				 */
				System.out.println("\n*****************Datei l�schen *********************\n");
				File alleKontenInDatei = new File(
						"C:\\Users\\alfa\\eclipse-workspace\\abschluss_projekt_banking_system\\objektKonto\\konto.kontenListe");
//			System.out.println(alleKontenInDatei.getAbsolutePath());
				File allekontenInDateitxt = new File("objektKonto/alleKonten.txt");
				alleKontenInDatei.delete();
				allekontenInDateitxt.delete();
				System.out.println("Datei wird gel�scht.");
				System.out.println("\n******************************Bis Bald!******************************");
			} else {
				System.out.println("\n******************************Tsch�ss!******************************");
			}
			return; // Beendet die Rekursion
		}
		navigierenManagerMenue(); // die Rekursion findet hier statt

	}

	/**
	 * Starten die Navigation Menu von KundenInterface
	 * 
	 * @throws Exception rekursive Methode
	 */
	public void navigierenKundeMenue() throws Exception {
		System.out.println("\nWillkommen bei der Kunden-Menue-Navigation\n");
		System.out.println("Bitte w�hlen Sie eine Menu-option aus!:\n\t" + "1: einloggen\n\t"
				+ "2: Geld im Konto einzahlen\n\t" + "3: Geld im Konto auszahlen\n\t" + "4: Geld �berweisen\n\t"
				+ "5: anzeigen KundeLogindaten\n\t" + "6: anzeigen alle von mir verf�gbare Konten\n\t"
				+ "7: ausloggen\n\t" + "oder Programm beenden mit jeder anderen Zahleingabe");
		int choice = new Scanner(System.in).nextInt();
		switch (choice) {
		case 1:
			einloggen();
			break;
		case 2:
			einzahlenGeld();
			break;
		case 3:
			try {
				auszahlenGeld();
			} catch (Exception ausnahme) {
				System.out.println(ausnahme);
				System.out.println("Einen weiteren Versuch hast du noch");
				try {
					auszahlenGeld();
				} catch (Exception problem) {
					problem.printStackTrace();
				}
			}
			try {
				Thread.sleep(10);
			} catch (InterruptedException problem) {
				System.out.println(problem);
			}
			break;
		case 4:
			ueberweisenGeld();
			break;
		case 5:
			anzeigenKundenLoginDaten();
			break;
		case 6:
			anzeigenAlleKontenEinesKunde();
		case 7:
			navigierenManagerMenue();
			break;
		default:
			System.out.println("\nProgramm wird beendet.");
			System.exit(-1);
			return; // Beendet die Rekursion
		}
		navigierenKundeMenue();
	}

	/**
	 * anzeigen alle Konten eines selben Namen, da ein Kunde kann mehrere Konten im
	 * System haben
	 */
	private void anzeigenAlleKontenEinesKunde() {
		Scanner lesenId = new Scanner(System.in);
		System.out.println("Geben Sie bitte Ihr Name ein!");
		String kundenName = lesenId.nextLine();

		List<Kunde> kunden = kundenService.auswaehlenallerKontendieserKunde(kundenName);
		List<Konto> konten = kurs245Services.getAlleKonten();

		if (kunden.size() == 0) {
			System.out.println("Keine Kunden mit dieser name gefunden!");
		}
		System.out.println("Name " + "\tAdresse " + "\tId " + "\tPasswort" + "\tKundenummer" + "\tKundenpasswort");
		for (Kunde kunde : kunden) {
			kunde.anzeigenKundenInformationen();
		}

	}

	/**
	 * einloggen eines Kunde im System
	 * 
	 * @return
	 */
	private boolean einloggen() {
		/** KundenId eingeben und einlesen */
		Scanner lesenId = new Scanner(System.in);
		System.out.println("Geben Sie bitte Ihr KundeId ein!");
		int kundenId = lesenId.nextInt();

		/** Kundepasswort eingeben und einlesen */
		Scanner lesenPasswort = new Scanner(System.in);
		System.out.println("Geben Sie bitte ein Passwort ein!");
		String passwort = lesenPasswort.nextLine();

		List<Kunde> alleKunden = kundenService.auswaehlenKundenId(kundenId);
		if (alleKunden.size() == 0) {
			System.out.println("Kundenliste ist leer!");
		}

		for (Kunde kunde : alleKunden) {
			try {
				kunde.einloggen(kundenId, passwort);
			} catch (Exception problem) {
				problem.printStackTrace();
			}
		}
		return true;
	}

	/**
	 * anzeigen die Kunden Logindaten (KundenId uns Passwort
	 */
	private void anzeigenKundenLoginDaten() {
		System.out.println("Geben Sie bitte Ihre KundenId ein!");
		Scanner lesen = new Scanner(System.in);
		int kundenId = lesen.nextInt();

		List<Kunde> alleKunden = kundenService.auswaehlenKundenId(kundenId);
		if (alleKunden.size() == 0) {
			System.out.println("Kundenliste ist leer!");
		}
		for (Kunde kunde : alleKunden) {
			System.out.println("kundenId: " + kunde.getKundenId() + " Kundenpasswort: " + kunde.getKundenPasswort());
		}
	}

	/**
	 * anzeigen die Liste allerKunde
	 */
	public void anzeigenAllerKunden() {
		System.out.println("\n*************Liste aller Kunden sind: *****************************");
		System.out.println("Name " + "\tAdresse " + "\tId " + "\tPasswort");
		List<Kunde> alleKunden = kundenService.getAlleKunden();
		alleKunden.forEach(kunde -> kunde.anzeigenKundenInformationen());

		System.out.println("*************Ende von dem Anzeigen Kundenliste *********************\n");

	}

	/**
	 * �berweisen Geld in ein Konto pr�fen ob die Konten vom Sender und vom
	 * Empf�nger in System vorhanden sind oder nicht, da eine �berweisung nur
	 * m�glich ist wenn die Konten existiert
	 * 
	 * @throws Exception
	 */
	public void ueberweisenGeld() throws Exception {
		System.out.println("\n*******************�berweisung durchf�hren!*********************");

		Scanner lesen = new Scanner(System.in);
		System.out.println("Geben Sie bitte Ihre Kontonnumer ein:");
		int kontoNummerVonSender = lesen.nextInt();

		/** suchen von Kontonummer in unserem System */
		int indexVonSender = kurs245Services.suchenKontonummerIndex(kontoNummerVonSender);
		if (indexVonSender == -1) { // pr�fen, ob das Konto existiert
			System.err.println("Leider k�nnen wir dieses Konto in unsere Datenbank nicht finden.");
			return;
		}

		System.out.println("Geben Sie bitte die Kontonnumer des Empfaengers ein:");
		int kontoNummerDesEmpfaengers = lesen.nextInt();

		/** suchen von Kontonummer in unserem System */
		int indexVonEmpfaenger = kurs245Services.suchenKontonummerIndex(kontoNummerDesEmpfaengers);
		if (indexVonEmpfaenger == -1) { // pr�fen, ob das Konto existiert
			System.err.println("Leider k�nnen wir dieses Konto in unsere Datenbank nicht finden.");
			return;
		}

		System.out.println("Wie viel Geld wollen Sie in Kontonummer: " + kontoNummerDesEmpfaengers + " �berweisen? ");
		double betrag = lesen.nextDouble();

		List<Konto> konten = kurs245Services.getAlleKonten();
		if (konten.get(indexVonSender).auszahlenGeldVomKonto(betrag)) {
			System.out.println("Ein Betrag in H�he von: " + betrag + " wird erfolgsreich von Ihrem Konto abgebucht");
		}
		if (konten.get(indexVonEmpfaenger).einzahlenGeldInKonto(betrag)) {
			System.out.println(
					kontoNummerDesEmpfaengers + " hat ein Betrag in H�he von: " + betrag + " von der Kontonummer: "
							+ kontoNummerVonSender + " erhalten und es wird erfolgsreich in Ihrem Konto eingezahlt");
		}
	}

	/**
	 * auszahlen Geld in ein Konto pr�fen ob das Konto in System vorhanden ist oder
	 * nicht, da eine Auszahlung nur m�glich ist wenn das Konto existiert
	 * 
	 * @throws Exception
	 */
	public void auszahlenGeld() throws Exception {
		System.out.println("\n*****************Geld auszahlen******************************");

		System.out.println("Geben Sie bitte die Kontonnumer ein!");
		Scanner lesen = new Scanner(System.in);
		int kontoNummer = lesen.nextInt();

		int index = kurs245Services.suchenKontonummerIndex(kontoNummer);
		if (index == -1) {
			System.err.println("Leider k�nnen wir dieser Konto in unsere Datenbank nicht finden.");
			return;
		}

		System.out.println("Wie viel Geld wollen Sie in Ihrem Konto auszahlen?");
		double betrag = lesen.nextDouble();

		List<Konto> konten = kurs245Services.getAlleKonten();
		if (konten.get(index).auszahlenGeldVomKonto(betrag)) {
			System.out.println("Der Betrag in H�he von: " + betrag + " wird erfolgsreich in Ihrem Konto ausgezahlt");
		}

		System.out.println("*************Auszahlung ist fertig*****************************\n");

	}

	/**
	 * einzahlen Geld in ein Konto pr�fen ob das Konto in System vorhanden ist oder
	 * nicht, da eine Einzahlung nur m�glich ist wenn das Konto existiert
	 */
	public void einzahlenGeld() {
		System.out.println("\n*****************Geld einzahlen******************************");

		System.out.println("Geben Sie bitte die Kontonnumer ein, die Den betrag bekommen wird: ");
		Scanner lesen = new Scanner(System.in);
		int kontoNummer = lesen.nextInt();

		int index = kurs245Services.suchenKontonummerIndex(kontoNummer);
		if (index == -1) {
			System.err.println("Leider k�nnen wir dieser Konto in unsere Datenbank nicht finden.");
			return;
		}

		System.out.println("Wie viel Geld wollen Sie in Ihrem Konto einzahlen?");
		double betrag = lesen.nextDouble();

		List<Konto> konten = kurs245Services.getAlleKonten();
		if (konten.get(index).einzahlenGeldInKonto(betrag)) {
			System.out.println("Der Betrag in H�he von: " + betrag + " wird erfolgsreich in Ihrem Konto eingezahlt");
		}

		System.out.println("*************Einzahlung ist fertig*****************************\n");
	}

	/**
	 * l�schen ein Konto in das System pr�fen ob das Konto in System vorhanden ist
	 * oder nicht, da eine L�schung nur m�glich ist wenn das Konto existiert
	 */
	public void loeschenEinKonto() {
		System.out.println("\n*************************Konto von unserem System l�schen***********************");

		System.out.println("Geben Sie bitte die Kontonummer ein, die Sie l�schen wollen!");
		Scanner lesen = new Scanner(System.in);
		int kontoNummer = lesen.nextInt();

		int index = kurs245Services.suchenKontonummerIndex(kontoNummer);
//		System.out.println("index dieser Kontonummer ist: " + index);
		if (index == -1) {
			System.err.println("Leider k�nnen wir dieser Konto in unsere Datenbank nicht finden.");
			return;
		}
		List<Kunde> alleKunden = kundenService.getAlleKunden();
		List<Konto> konten = kurs245Services.getAlleKonten();

		for (Kunde kunde : alleKunden) {
			int KundenummerIndex = kundenService.suchenKundenummerIndex(kunde.getKundenId());
			konten.remove(index);
			alleKunden.remove(KundenummerIndex);
		}
//		konten.remove(index);

//		alleKunden.remove(kontoNummer);

		System.out.println("***********Der Konto mit der Kontonummer " + kontoNummer
				+ " wird erfolgsreich gel�scht***************\n");
	}

	/**
	 * suchen ein Konto in das System pr�fen ob das Konto in System vorhanden ist
	 * oder nicht.
	 */
	public void suchenEinKonto() {
		System.out.println("\n***************Konto in unserem System suchen********************");

		System.out.println("Geben Sie bitte die Kontonummer ein, die Sie suchen wollen!");
		Scanner lesen = new Scanner(System.in);
		int kontoNummer = lesen.nextInt();
		List<Konto> konten = kurs245Services.auswaehlenKontonummer(kontoNummer);
		if (konten.size() == 0) {
			System.err.println("Leider k�nnen wir dieses Konto in unsere Datenbank nicht finden.");
			return;
		}
		System.out.println("Kontonummer\t" + "Name\t" + "Adresse\t" + "Kontostand\t" + "Kontoart");
		/** Lamda-Ausdruck */
		konten.forEach(konto -> konto.anzeigenKontoDetails());

		System.out.println("******************Suche ist fertig********************************\n");
	}

	/**
	 * anzeigen die Liste alle Konten in Form einer tabelle pr�fen ob die Liste leer
	 * ist oder nicht
	 */
	public void anzeigenAlleKonten() {
		System.out.println("\n*************Liste aller Konten sind: *****************************");
		List<Konto> konten = kurs245Services.getAlleKonten();
		if (konten.size() == 0) {
			System.out.println("\nDie Datenbank is leer. Bite legen Sie neue Konten in Ihrem System ein.\n");
		} else {
			System.out.println("Kontonummer\t" + "Name\t" + "Adresse\t" + "Kontostand\t" + "Kontoart");
			/** Erweiterte For-Schleife */
			for (Konto konto : konten) {
				konto.anzeigenKontoDetails();
			}
		}

		System.out.println("*************Ende von dem Anzeigen aller KontenListe *********************\n");
	}

	/**
	 * ein neues Konto er�ffnen mit den dazugeh�rigen Daten zuf�gen dieses neue
	 * Konto in die Kontenliste schreiben neues Konto in einer Textdatei
	 * 
	 * @throws Exception
	 */
	public void anlegenNeuesKonto() {
		System.out.println("\n*********************Er�ffung eines Konto wird gestartet*********************");

		Scanner lesen = new Scanner(System.in);

		/** Name des Kunde eingeben */
		System.out.println("Geben Sie der Name des Kunde bzw. des Besitzer ein!");
		String name = lesen.nextLine();

		System.out.println("Geben Sie bitte die Adresse des Kunde ein!");
		String adresse = lesen.nextLine();

		System.out.println("Geben Sie bitte ein Passwort f�r den Kunde ein!");
		String passwort = lesen.nextLine();

		Kunde neuerKunde = new Kunde(name, adresse, passwort); // erzeugt des neue Kunde
		Konto neuesKonto = null;

		System.out.println("Bitte w�hlen Sie ein Kontotyp aus!");
		/** Array f�r die Kontotypen in Enums */
		Kontotyp[] kontoArten = Kontotyp.values();
//		System.out.println("L�nge der Kontotyp: " + kontoArten.length);
		for (int i = 0; i < kontoArten.length; i++) {
			System.out.println((i + 1) + "- " + kontoArten[i]);
		}

		/** Liset die Auswahl vom benutzer aus */
		int auswahlKontoart = lesen.nextInt();
		/**
		 * pr�fen, die Eingabe bzw. die Auswahl des Benutzers, ob die eingegebene Zahl
		 * entweder 1 oder 2 ist. Wenn nein, wird eine Ausnahme in die Konsole geworfen
		 */
		if (auswahlKontoart != 1 && auswahlKontoart != 2) {
			System.err.println("Falsche Zahleingabe. Bitte geben sie entweder 1 oder 2 ein!");
			return;
		}

		if (auswahlKontoart == 1) {
			System.out.println("Wie viel Geld wollen Sie sofort bei der Er�ffnung einzahlen?");
			double betrag = lesen.nextDouble();
			neuesKonto = new Konto(betrag, Kontotyp.GIROKONTO);
		} else if (auswahlKontoart == 2) {
			System.out
					.println("Wie viel Geld wollen Sie sofort bei der Er�ffnung einzahlen? Bitte Betrag >= 100� danke");
			double betrag = lesen.nextDouble();
			if (betrag < 100) {
				System.err.println("Betrag ist unreichend. geben Sie bitte ein Mindestbetrag von 100�!");
				return;
			} else {
				neuesKonto = new Sparkonto(betrag, Kontotyp.SPARKONTO);
			}

		}
		neuesKonto.setKunde(neuerKunde);
		neuerKunde.setKonto(neuesKonto);
		kurs245Services.zufuegenNeuesKonto(neuesKonto);
		kundenService.zufuegenNeuerKunde(neuerKunde);

		// Schreiben von Objekt Konto in Datei
		/**
		 * Referenz Attribut f�r das Schreiben eines Objekts (Liste aller Konten in
		 * einer Datei schreiben)
		 */
		KontoSchreiber schreiberInDatei = new KontoSchreiber();
//		String dateiTitle = "\n*************************Liste aller Konten in unserem System*****************";
//		dateiTitle += "\nKontonummer\t" + "Kundenname\t" + "Kontotyp\t" + "Kontostand";
//		schreiberInDatei.schreibenVonKontoInformationenInDatei(new File("objektKonto/alleKonten.txt"), dateiTitle);
		String text = "\n" + neuesKonto.getKontoNummer() + "\t\t\t" + neuerKunde.getName() + "\t"
				+ neuesKonto.getKontoArt() + "\t" + neuesKonto.getKontostand();
		schreiberInDatei.schreibenVonKontoInformationenInDatei(new File("objektKonto/alleKonten.txt"), text);

		System.out.println("*********************Das neue Konto wird erfolgsreich ge�ffnet.*********************\n");
	}
}
