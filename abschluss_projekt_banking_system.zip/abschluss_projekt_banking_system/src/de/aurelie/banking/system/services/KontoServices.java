package de.aurelie.banking.system.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.aurelie.banking.system.Konto;

/**
 * Bekommt Konto Daten aus dem Backend (Klasse Konto) .
 * Stellt Services zur Verf�gung um Daten auszuwerten und auszuw�hlen f�r die Verarbeitung
 * 
 * @author Aurelie Koumtossa
 */
public class KontoServices {

	/** enth�lt die Liste alle Konten*/
	private List<Konto> alleKonten = new ArrayList<Konto>();

	/************************ Konstruktor *************************************/
	
	/**
	 * erzeugt ein kontoservices mit der Liste alle Konten
	 */
	public KontoServices() {
		this.alleKonten = getAlleKonten();
	}
	
	/**
	 * @return the alleKonten: Die Liste alle Konten
	 */
	public List<Konto> getAlleKonten() {
		return alleKonten;
	}

	/**
	 * zuf�gen ein neues Konto in die gesamte Kontenliste
	 * @param konto 
	 */
	public void zufuegenNeuesKonto(Konto konto) {
		alleKonten.add(konto);
	}

	/**
	 * ausw�hlen ein Konto bzw. suchen Kontonummer in die gesamte Kontoliste 
	 * @param kontoNummer die kontonummer, die ausgew�hlt wird
	 * @return auswahl der ausgew�hlte Konto in die Liste wird ausgegeben
	 */
	public List<Konto> auswaehlenKontonummer(int kontoNummer) {
		List<Konto> auswahl = new ArrayList<Konto>();
		for(Konto kontoAuswahl : alleKonten ) {
			if(kontoNummer == kontoAuswahl.getKontoNummer()) {
				auswahl.add(kontoAuswahl);
			}
		}
		return auswahl;
	}
	
	public List<Konto> auswaehlenalleKontoEinesKunde(String name){
		List<Konto> auswahlAlleSeinerKonten = new ArrayList<Konto>();
		for(Konto kontoAuswahl : alleKonten ) {
			
		}
		return auswahlAlleSeinerKonten;
	}

	/**
	 * suchen der Index eines Konto mitHilfe seiner Kontonummer
	 * @param kontoNummer
	 * @return die Position der Kontonummer
	 */
	public int suchenKontonummerIndex(int kontoNummer) {
		for (int i = 0; i < alleKonten.size(); i++) {
			if (kontoNummer == alleKonten.get(i).getKontoNummer()) {
				return i;
			}
		}
		return -1;
	}
	
//	public Set<String> sucherAllerKontenEinesKunde(){
//		Set<String> namen = new HashSet <String>();
//		for(Konto guru: alleAmigurumis) {
//			namen.add(guru.getName());
//		}
//		return namen;
//	}
	
}
