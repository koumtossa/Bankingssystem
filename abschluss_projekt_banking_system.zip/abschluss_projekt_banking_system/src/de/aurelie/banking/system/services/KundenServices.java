package de.aurelie.banking.system.services;

import java.util.ArrayList;
import java.util.List;

import de.aurelie.banking.system.Kunde;

/**
 * Bekommt Kunde Daten aus dem Backend (Klasse Kunde) . Stellt Services zur
 * Verf�gung um Daten auszuwerten und auszuw�hlen f�r die Verarbeitung
 * 
 * @author Aurelie Koumtossa
 */
public class KundenServices {

	/** enth�lt die Liste alle Konten */
	private List<Kunde> alleKunden = new ArrayList<Kunde>();

	/**
	 * @param alleKunden
	 */
	public KundenServices() {
		this.alleKunden = getAlleKunden();
	}

	/**
	 * 
	 * @return
	 */
	public List<Kunde> getAlleKunden() {
		return alleKunden;
	}

	/**
	 * 
	 * @param neuerKunde
	 */
	public void zufuegenNeuerKunde(Kunde neuerKunde) {
		alleKunden.add(neuerKunde);

	}

	/**
	 * ausw�hlen ein KundeId in die Liste aller Konten
	 * 
	 * @param kundenId , die ausgew�hlt wird
	 * @return die ausgew�hlte KundenId von der gesamte Kundenliste
	 */
	public List<Kunde> auswaehlenKundenId(int kundenId) {
		List<Kunde> auswahl = new ArrayList<Kunde>();
		for (Kunde kundenIdAuswahl : alleKunden) {
			if (kundenId == kundenIdAuswahl.getKundenId()) {
				auswahl.add(kundenIdAuswahl);
			}
		}
		return auswahl;
	}

	/**
	 * ausw�hlen aller Konten eines selben Kunden pr�fen erfolgt durch sein name
	 * 
	 * @param name
	 * @return
	 */
	public List<Kunde> auswaehlenallerKontendieserKunde(String name) {
		List<Kunde> auswahl = new ArrayList<Kunde>();
		for (Kunde kundenAuswahl : alleKunden) {
			if (name.equals(kundenAuswahl.getName())) {
				auswahl.add(kundenAuswahl);
			}
		}
		return auswahl;
	}

	/**
	 * suchen der Index eines Kunde mitHilfe seiner Kontonummer
	 * 
	 * @param kontoNummer
	 * @return die Position der Kontonummer
	 */
	public int suchenKundenummerIndex(int kundenId) {
		for (int i = 0; i < alleKunden.size(); i++) {
			if (kundenId == alleKunden.get(i).getKundenId()) {
				return i;
			}
		}
		return -1;
	}
}
