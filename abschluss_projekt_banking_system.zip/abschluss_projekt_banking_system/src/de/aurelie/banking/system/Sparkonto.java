package de.aurelie.banking.system;

/**
 * Die Klasse Sparkonto, die von der Klasse Konto erbt, weist die Besonderheit
 * auf, dass die Methoden abhebenGeld() und einzahlenGeld der Oberklasse in der
 * Unterklasse �berschrieben wird. Damit wird sichergestellt, dass durch eine
 * Auszahlung der Kontostand eines Sparkonto-Objektes nicht negativ wird.
 * Ein Mindestkontostand von 100 muss immer sein
 * @author Aurelie Koumtossa
 *
 */

public class Sparkonto extends Konto {

	/*********************************** Die Attribute *******************************/
	
	/** default serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	/** Ein Sparkonto muss ein Mindestsaldo enthalten */
	private double mindestKontostand;
	

	/*************************************** Konstruktoren *********************/
	
	/**
	 * erzeugt eines enue Sparkonto 
	 * mit mindestKontostand von 100;
	 */
	public Sparkonto() {
		super(100, Kontotyp.SPARKONTO);
		mindestKontostand = 100;
//		this.name = "Sparkonto";
	}

	/**
	 * erzeugt eines neue Sparkonto mit kontostand und kontotyp
	 * @param kontostand
	 * @param kontoArt
	 */
	public Sparkonto(double kontostand, Kontotyp kontoArt) {
		super(kontostand, Kontotyp.SPARKONTO);
		mindestKontostand = 100;
//		this.name = "Sparkonto";
	}

	/********************************************* DIe Getters ****************************/
	/**
	 * 
	 * @return
	 */
	public double getMindestKontostand() {
		return mindestKontostand;
	}

	/****************** Die Setters*************************************************/

	/**
	 * 
	 * @param mindestKontostand
	 */
	public void setMindestKontostand(double mindestKontostand) {
		this.mindestKontostand = mindestKontostand;
	}

	/*********************************** Die Methoden �berschreiben ***********************************/
	/**
	 * �berschreiben von Methode auszahlenGeldVomKonto() der Oberklasse Konto
	 * auszahlen m�glich nur wenn im Konto noch mindestens 100� bleibt
	 * auszahlen m�glich f�r nur positive Werte(betrag)
	 * @param betrag betrag, der man im Konto auszahlen will
	 * @param Exception
	 */
	@Override
	public boolean auszahlenGeldVomKonto(double betrag) throws Exception{
		if (kontostand - betrag >= mindestKontostand) {
			kontostand -= betrag;
			return true;
		}
		if (betrag < 0) {
			throw new Exception("Bitte geben Sie einen positiver Wert ein!");
		}
		throw new Exception("Bitte anderer Betrag eingeben, damit Sie den Mindestbetrag in H�he von 100� immer zur Verf�gung steht!");
	}

	/**
	 * �berschreiben von Methode einzahlenGeldInKonto() der Oberklasse Konto
	 * einzahlen beim Sparkonto m�glich nur beim mindestbetrag von 10�
	 * @param betrag betrag, der man im Konto einzahlen will
	 */
	@Override
	public boolean einzahlenGeldInKonto(double betrag) {
		if (betrag < 10) {
			System.err.println("Betrag ist unreichend. geben Sie bitte ein Mindestbetrag von 10�!");
			return false;
		}
		kontostand = kontostand + betrag;
		return true;
	}

	
}
