package de.aurelie.banking.system;

/**
 * Instanzieren von festen Kontotypen (GIROKONTO und SPARKONTO)
 * Beim Anlegen eines neues Konto kann man entweder 1 als Girokonto oder 2 als Sparkonto
 * 
 * @author Aurelie Koumtossa
 *
 */
public enum Kontotyp {

	 GIROKONTO, SPARKONTO;
}
